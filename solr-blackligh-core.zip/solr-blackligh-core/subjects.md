These charts lists the most common terms and spellings for Subjects
in the GeoBlacklight community.

## Geospatial Data

Common spelling | Related terms
|----|-------------
Farming | Agriculture
Biota | Biology |ISO Topic Category
Boundaries | Administrative and political boundaries; Cities and towns
Climatology, Meteorology, and Atmosphere | Climate
Economy
Elevation
Environment |
Geoscientific Information | Geology
Health ||
Imagery and Base Maps | Imagery; Basemaps; Landcover
Intelligence and Military |
Inland Waters |
Location |
Oceans |
Planning and Cadastral | Property
Society |
Structure | Facilities and Structures
Transportation |
Utilities and Communications | Utilities

## Maps

Common spelling | Related terms
|:---- |:------------- |
Aeronautical charts
Atlases
Bathymetric maps
Cadastral maps
Fire insurance maps
Geological maps
Road maps
Thematic maps
Topographic maps
Tourist maps
